<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class UserAuthController extends Controller
{
    
    /// register user with passport 

    public function register(Request $request){
        $request->validate([
            'name' => 'required',
            'email' => 'required|email',
            'password' => 'required|min:6'
        ]);
        /// upload image 
        /// if has image 
        $imageName = '';
        if($request->hasFile('image')){
            $imageName = time().'.'.$request->image->extension();
            $request->image->move(public_path('images'), $imageName);
        }
     
        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => bcrypt($request->password),
            'image' => $imageName ?? null
        ]);


       

        $token = $user->createToken('authToken')->accessToken;

        return response()->json([
            'status' => 'success',
            'data' => $token
        ]);
    }
    /// login 
    public function login(Request $request){
        $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:6'
        ]);
        $credentials = $request->only('email','password');
        if(auth()->attempt($credentials)){
            $token = auth()->user()->createToken('authToken')->accessToken;
            return response()->json([
                'status' => 'success',
                'data' => $token
            ]);
        }else{
            return response()->json([
                'status' => 'error',
                'data' => 'invalid credentials'
            ], 401);
        }
    }
}
